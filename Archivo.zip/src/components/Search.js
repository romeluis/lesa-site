import { useState } from "react";

const Search = (props) => {
    const searchQuery = props.query;

    return (  
        <div>
            
        </div>
    );
}
 
export default Search;